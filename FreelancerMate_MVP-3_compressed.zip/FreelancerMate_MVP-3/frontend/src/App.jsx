import { useEffect, useMemo, useState } from 'react'
import { LayoutDashboard, FileText, PlusCircle, Wallet, Bell, Sparkles, CheckCircle2, Clock3, Trash2, RefreshCw, BarChart3, ShieldAlert } from 'lucide-react'
import { PayPalButtons, PayPalScriptProvider } from '@paypal/react-paypal-js'
import './modules/modules.css'
import AiAssistWidget from './modules/AiAssistWidget'
import CustomAnalytics from './modules/CustomAnalytics'
import ManagementSupport from './modules/ManagementSupport'

const API = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000'
const money = n => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(Number(n || 0))

export default function App() {
  const [page, setPage] = useState('dashboard')
  const [stats, setStats] = useState({})
  const [invoices, setInvoices] = useState([])
  const [prompt, setPrompt] = useState('')
  const [draft, setDraft] = useState({ customer: '', service: '', amount: '', due_date: '' })
  const [notice, setNotice] = useState('')
  const [busy, setBusy] = useState(false)
  const [aiEnabled, setAiEnabled] = useState(false)
  const [paypalConfig, setPaypalConfig] = useState({ enabled: false, client_id: null, currency: 'INR', mode: 'sandbox' })

  async function request(path, options = {}) {
    const res = await fetch(`${API}${path}`, {
      ...options,
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
    })
    const data = await res.json()
    if (!res.ok) throw new Error(data.detail || data.error || 'Request failed')
    return data
  }

  async function refresh() {
    try {
      const [s, list, paypal] = await Promise.all([request('/dashboard'), request('/invoices'), request('/paypal/config')])
      setStats(s); setInvoices(list); setPaypalConfig(paypal)
    } catch (e) { setNotice(`Backend connection error: ${e.message}`) }
  }

  useEffect(() => { refresh() }, [])

  async function parsePrompt(e) {
    e.preventDefault(); setBusy(true); setNotice('')
    try {
      const data = await request('/ai/parse', { method: 'POST', body: JSON.stringify({ prompt }) })
      setAiEnabled(data.ai_enabled)
      setDraft(d => ({ ...d, ...data.fields, amount: data.fields.amount || '' }))
      if (data.missing_fields.length) setNotice(`Please complete: ${data.missing_fields.join(', ')}`)
      else setNotice('Details extracted. Review the fields and create your invoice.')
      setPage('create')
    } catch (e) { setNotice(e.message) } finally { setBusy(false) }
  }

  async function createInvoice(e) {
    e.preventDefault(); setBusy(true); setNotice('')
    try {
      await request('/invoices', { method: 'POST', body: JSON.stringify({ ...draft, amount: Number(draft.amount) }) })
      setDraft({ customer: '', service: '', amount: '', due_date: '' }); setPrompt('')
      setNotice('Invoice saved successfully. It is waiting for your approval.')
      await refresh(); setPage('invoices')
    } catch (e) { setNotice(e.message) } finally { setBusy(false) }
  }

  async function changeStatus(id, action) {
    try {
      await request(`/invoices/${id}/${action}`, { method: 'PATCH' })
      setNotice(action === 'paid' ? 'Payment marked as received.' : 'Invoice status updated.')
      refresh()
    } catch (e) { setNotice(e.message) }
  }

  async function createPayPalOrder(id) {
    try {
      const result = await request(`/invoices/${id}/paypal/order`, { method: 'POST' })
      return result.order_id
    } catch (e) {
      setNotice(e.message)
      throw e
    }
  }

  async function capturePayPalOrder(id, orderId) {
    try {
      await request(`/invoices/${id}/paypal/capture`, {
        method: 'POST',
        body: JSON.stringify({ order_id: orderId })
      })
      setNotice('PayPal confirmed payment for this invoice.')
      await refresh()
    } catch (e) {
      setNotice(e.message)
      throw e
    }
  }

  function reportPayPalError(error) {
    setNotice(error?.message || 'PayPal checkout could not be completed.')
  }

  async function removeInvoice(id) {
    if (!window.confirm('Delete this invoice?')) return
    try { await request(`/invoices/${id}`, { method: 'DELETE' }); refresh(); setNotice('Invoice deleted.') }
    catch (e) { setNotice(e.message) }
  }

  const pending = useMemo(() => invoices.filter(x => x.status !== 'Paid'), [invoices])

  const content = <div className="shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-icon"><Wallet size={21} /></div><div><b>FreelancerMate</b><small>AI financial assistant</small></div></div>
      <div className="nav-label">WORKSPACE</div>
      <button className={page === 'dashboard' ? 'nav active' : 'nav'} onClick={() => setPage('dashboard')}><LayoutDashboard size={18} /> Dashboard</button>
      <button className={page === 'invoices' ? 'nav active' : 'nav'} onClick={() => setPage('invoices')}><FileText size={18} /> Invoices</button>
      <button className={page === 'create' ? 'nav active' : 'nav'} onClick={() => setPage('create')}><PlusCircle size={18} /> Create invoice</button>
      <div className="nav-label" style={{ marginTop: 14 }}>ADVANCED MODULES</div>
      <button className={page === 'analytics' ? 'nav active' : 'nav'} onClick={() => setPage('analytics')}><BarChart3 size={18} /> Custom Analytics</button>
      <button className={page === 'management' ? 'nav active' : 'nav'} onClick={() => setPage('management')}><ShieldAlert size={18} /> Management & Support</button>
      <div className="sidebar-bottom"><div className="mini-card"><Sparkles size={17} /><b>Work smarter</b><p>Turn your invoice requests into organised records.</p></div><small>FreelancerMate · MVP</small></div>
    </aside>

    <main className="main">
      <header className="topbar"><div><span className="eyebrow">YOUR FINANCE WORKSPACE</span><h1>{page === 'dashboard' ? 'Dashboard' : page === 'invoices' ? 'Invoices' : page === 'create' ? 'Create an invoice' : page === 'analytics' ? 'Custom Analytics' : 'Management & Support'}</h1></div><button className="refresh" onClick={refresh}><RefreshCw size={16} /> Refresh</button></header>
      {notice && <div className="notice" role="status">{notice}<button onClick={() => setNotice('')}>×</button></div>}

      {page === 'dashboard' && <section>
        <div className="welcome"><div><span className="eyebrow light">OVERVIEW</span><h2>Keep your freelance finances in view.</h2><p>Track invoices, monitor payments and stay organised.</p></div><div className="welcome-mark"><Wallet size={48} /></div></div>
        <div className="stats">
          <Stat icon={<Wallet />} label="Total earnings" value={money(stats.total_earnings)} detail="Invoices marked paid" />
          <Stat icon={<Clock3 />} label="Pending amount" value={money(stats.pending_amount)} detail="Not yet marked paid" />
          <Stat icon={<FileText />} label="Total invoices" value={stats.total_invoices || 0} detail="All saved invoices" />
          <Stat icon={<CheckCircle2 />} label="Paid invoices" value={stats.paid_count || 0} detail={`${stats.pending_count || 0} awaiting payment`} />
        </div>
        <div className="section-head"><div><h3>Recent invoices</h3><p>Your latest invoice activity</p></div><button className="text-btn" onClick={() => setPage('invoices')}>View all →</button></div>
        <InvoiceTable invoices={invoices.slice(0, 5)} onApprove={id => changeStatus(id, 'approve')} onPaid={id => changeStatus(id, 'paid')} onDelete={removeInvoice} paypalEnabled={paypalConfig.enabled} onCreatePayPalOrder={createPayPalOrder} onCapturePayPalOrder={capturePayPalOrder} onPayPalError={reportPayPalError} />
      </section>}

      {page === 'create' && <section className="create-grid">
        <div className="panel">
          <div className="panel-title"><Sparkles size={19} /><div><h3>Describe your invoice</h3><p>Write naturally. Review the extracted details before saving.</p></div></div>
          <form onSubmit={parsePrompt}>
            <label>Invoice request</label>
            <textarea rows="4" value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Create an invoice for Arun for ₹12,000 for logo design" required />
            <button className="primary" disabled={busy}>{busy ? 'Working…' : 'Extract invoice details'}</button>
          </form>
          <div className="tip"><Sparkles size={16} /><span>{aiEnabled ? 'Gemini extraction is enabled.' : 'Local extraction is active. Add a Gemini API key to enable AI-powered extraction.'}</span></div>
        </div>
        <div className="panel">
          <div className="panel-title"><FileText size={19} /><div><h3>Review invoice</h3><p>Check the information before saving.</p></div></div>
          <form onSubmit={createInvoice}>
            <label>Customer name</label><input value={draft.customer} onChange={e => setDraft({ ...draft, customer: e.target.value })} placeholder="e.g. Arun" required />
            <label>Service description</label><input value={draft.service} onChange={e => setDraft({ ...draft, service: e.target.value })} placeholder="e.g. Logo design" required />
            <label>Amount (INR)</label><input type="number" min="0.01" step="0.01" value={draft.amount} onChange={e => setDraft({ ...draft, amount: e.target.value })} placeholder="12000" required />
            <label>Due date (optional)</label><input type="date" value={draft.due_date} onChange={e => setDraft({ ...draft, due_date: e.target.value })} />
            <div className="preview-total"><span>Invoice total</span><b>{money(draft.amount)}</b></div>
            <button className="primary" disabled={busy || !draft.customer || !draft.service || !(Number(draft.amount) > 0)}>Save invoice for approval</button>
          </form>
        </div>
      </section>}

      {page === 'invoices' && <section><div className="section-head"><div><h3>All invoices</h3><p>{paypalConfig.enabled ? 'Approve invoices, then collect payments through PayPal.' : 'Approve invoices and update payment status.'}</p></div><button className="primary compact" onClick={() => setPage('create')}>+ New invoice</button></div><InvoiceTable invoices={invoices} onApprove={id => changeStatus(id, 'approve')} onPaid={id => changeStatus(id, 'paid')} onDelete={removeInvoice} paypalEnabled={paypalConfig.enabled} onCreatePayPalOrder={createPayPalOrder} onCapturePayPalOrder={capturePayPalOrder} onPayPalError={reportPayPalError} /></section>}

      {page === 'analytics' && <CustomAnalytics apiBase={API} />}
      {page === 'management' && <ManagementSupport apiBase={API} />}

      <footer>{paypalConfig.enabled ? `PayPal ${paypalConfig.mode} · Payments are confirmed by the server.` : 'FreelancerMate MVP · Local demo mode · Review all details before sending invoices.'}</footer>
    </main>

    {/* Floating AI Assistant Widget (non-intrusive, isolated) */}
    <AiAssistWidget apiBase={API} />
  </div>

  if (!paypalConfig.enabled || !paypalConfig.client_id) return content
  return <PayPalScriptProvider options={{ clientId: paypalConfig.client_id, currency: paypalConfig.currency, intent: 'capture' }}>{content}</PayPalScriptProvider>
}

function Stat({ icon, label, value, detail }) {
  return <div className="stat-card"><div className="stat-top"><span>{label}</span><div className="stat-icon">{icon}</div></div><strong>{value}</strong><small>{detail}</small></div>
}

function InvoiceTable({ invoices, onApprove, onPaid, onDelete, paypalEnabled, onCreatePayPalOrder, onCapturePayPalOrder, onPayPalError }) {
  if (!invoices.length) return <div className="empty"><FileText size={30} /><b>No invoices yet</b><span>Create your first invoice to see it here.</span></div>
  return <div className="table-wrap"><table><thead><tr><th>Customer / service</th><th>Amount</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead><tbody>
    {invoices.map(x => <tr key={x.id}><td><b>{x.customer}</b><small>{x.service}</small></td><td className="amount">{money(x.amount)}</td><td><span className={`status ${x.status === 'Paid' ? 'paid' : x.status === 'Approved' ? 'approved' : 'pending'}`}>{x.status}</span></td><td>{x.created_at ? new Date(x.created_at).toLocaleDateString('en-IN') : '—'}</td><td><div className="actions">{x.status === 'Pending Approval' && <button title="Approve" onClick={() => onApprove(x.id)}><CheckCircle2 size={16} /> Approve</button>}{paypalEnabled && x.status === 'Approved' && <div className="paypal-button-wrap"><PayPalButtons style={{ layout: 'horizontal', label: 'pay', height: 34 }} createOrder={() => onCreatePayPalOrder(x.id)} onApprove={data => onCapturePayPalOrder(x.id, data.orderID)} onError={onPayPalError} /></div>}{!paypalEnabled && x.status !== 'Paid' && <button title="Demo only: mark paid without PayPal" onClick={() => onPaid(x.id)}><Wallet size={16} /> Paid (demo)</button>}<button className="delete" title={x.paypal_order_id ? 'Invoices with a PayPal order cannot be deleted' : 'Delete'} disabled={Boolean(x.paypal_order_id)} onClick={() => onDelete(x.id)}><Trash2 size={16} /></button></div></td></tr>)}
  </tbody></table></div>
}
