import { useState, useRef, useEffect } from 'react'
import { Sparkles, MessageSquare, Send, X, Copy, Check, Bot, Lightbulb } from 'lucide-react'

export default function AiAssistWidget({ apiBase }) {
  const assistantUrl = import.meta.env.VITE_AI_AGENT_URL ||
    (import.meta.env.PROD ? '/api/assistant' : `${apiBase}/api/ai/assistant`)
  const [open, setOpen] = useState(false)
  const [input, setInput] = useState('')
  const [messages, setMessages] = useState([
    {
      sender: 'assistant',
      text: '👋 Hi! I am your AI Business Assistant. How can I assist you with your invoices, reminders, or finances today?'
    }
  ])
  const [loading, setLoading] = useState(false)
  const [copiedIndex, setCopiedIndex] = useState(null)
  const messagesEndRef = useRef(null)

  const quickPrompts = [
    'How much is pending?',
    'Draft a friendly reminder for Arun',
    'Who are my top clients?',
    'Tips to improve cash collection'
  ]

  useEffect(() => {
    if (open) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
    }
  }, [messages, open])

  async function sendMessage(textToSend) {
    const text = (textToSend || input).trim()
    if (!text || loading) return

    const newMsgs = [...messages, { sender: 'user', text }]
    setMessages(newMsgs)
    setInput('')
    setLoading(true)

    try {
      const res = await fetch(assistantUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text })
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || data.error || 'Assistant request failed.')
      setMessages([...newMsgs, { sender: 'assistant', text: data.reply || 'No response.' }])
    } catch (e) {
      setMessages([
        ...newMsgs,
        { sender: 'assistant', text: `⚠️ Unable to reach assistant: ${e.message}` }
      ])
    } finally {
      setLoading(false)
    }
  }

  function copyText(text, idx) {
    navigator.clipboard.writeText(text)
    setCopiedIndex(idx)
    setTimeout(() => setCopiedIndex(null), 2000)
  }

  return (
    <div className="ai-fab-container">
      {!open && (
        <button className="ai-fab-btn" onClick={() => setOpen(true)} title="Open AI Assistant">
          <span className="ai-badge-pulse" />
          <Sparkles size={17} />
          <span>AI Support Assistant</span>
        </button>
      )}

      {open && (
        <div className="ai-chat-window">
          <div className="ai-chat-header">
            <div>
              <b>
                <Bot size={18} /> FreelancerMate AI
              </b>
              <small>Live Financial Context Connected</small>
            </div>
            <button className="ai-close-btn" onClick={() => setOpen(false)} title="Close Assistant">
              <X size={18} />
            </button>
          </div>

          <div className="ai-messages-list">
            {messages.map((m, idx) => (
              <div key={idx} className={`ai-msg ${m.sender}`}>
                <div style={{ whiteSpace: 'pre-wrap' }}>{m.text}</div>
                {m.sender === 'assistant' && (
                  <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 4 }}>
                    <button
                      onClick={() => copyText(m.text, idx)}
                      style={{
                        background: 'transparent',
                        border: 'none',
                        color: '#64748b',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: 3,
                        fontSize: 10
                      }}
                      title="Copy text"
                    >
                      {copiedIndex === idx ? <Check size={12} color="#10b981" /> : <Copy size={12} />}
                      {copiedIndex === idx ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                )}
              </div>
            ))}
            {loading && (
              <div className="ai-msg assistant">
                <em>Thinking with financial context…</em>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="ai-quick-prompts">
            {quickPrompts.map((q, idx) => (
              <button key={idx} className="ai-chip" onClick={() => sendMessage(q)}>
                {q}
              </button>
            ))}
          </div>

          <form
            className="ai-input-bar"
            onSubmit={e => {
              e.preventDefault()
              sendMessage()
            }}
          >
            <input
              type="text"
              placeholder="Ask anything or request reminder drafts…"
              value={input}
              onChange={e => setInput(e.target.value)}
              disabled={loading}
            />
            <button type="submit" className="ai-send-btn" disabled={loading || !input.trim()}>
              <Send size={15} />
            </button>
          </form>
        </div>
      )}
    </div>
  )
}

