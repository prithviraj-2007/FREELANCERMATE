import { useState, useEffect } from 'react'
import {
  BarChart3,
  PlusCircle,
  TrendingUp,
  PieChart,
  Users,
  CheckCircle2,
  Clock3,
  AlertCircle,
  Trash2,
  Sparkles,
  RefreshCw
} from 'lucide-react'

const money = n =>
  new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2
  }).format(Number(n || 0))

export default function CustomAnalytics({ apiBase }) {
  const [dashboards, setDashboards] = useState([])
  const [activeDashId, setActiveDashId] = useState(null)
  const [aggregations, setAggregations] = useState(null)
  const [insights, setInsights] = useState(null)
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [newTitle, setNewTitle] = useState('')
  const [newDesc, setNewDesc] = useState('')
  const [selectedWidgets, setSelectedWidgets] = useState(['metric', 'customer_breakdown', 'status_chart', 'aging_summary'])
  const [loading, setLoading] = useState(false)
  const [notice, setNotice] = useState('')

  async function loadData() {
    setLoading(true)
    try {
      const [dashRes, aggRes, insRes] = await Promise.all([
        fetch(`${apiBase}/api/custom-dashboards`).then(r => r.json()),
        fetch(`${apiBase}/api/analytics/aggregations`).then(r => r.json()),
        fetch(`${apiBase}/api/ai/insights`).then(r => r.json())
      ])
      setDashboards(dashRes)
      setAggregations(aggRes)
      setInsights(insRes)
      if (dashRes.length > 0 && !activeDashId) {
        setActiveDashId(dashRes[0].id)
      }
    } catch (e) {
      setNotice(`Failed to load custom analytics: ${e.message}`)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadData()
  }, [])

  const currentDashboard = dashboards.find(d => d.id === activeDashId) || dashboards[0]

  async function handleCreateDashboard(e) {
    e.preventDefault()
    if (!newTitle.trim()) return

    const widgetsConfig = selectedWidgets.map((type, idx) => ({
      id: `w-${Date.now()}-${idx}`,
      type,
      title:
        type === 'metric'
          ? 'Financial Velocity'
          : type === 'customer_breakdown'
          ? 'Client Revenue Volume'
          : type === 'status_chart'
          ? 'Status Distribution'
          : 'Pending Receivables Aging'
    }))

    try {
      const res = await fetch(`${apiBase}/api/custom-dashboards`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newTitle.trim(),
          description: newDesc.trim(),
          widgets: widgetsConfig
        })
      })
      const created = await res.json()
      setDashboards([created, ...dashboards])
      setActiveDashId(created.id)
      setShowCreateModal(false)
      setNewTitle('')
      setNewDesc('')
      setNotice('Custom Dashboard created successfully!')
    } catch (e) {
      setNotice(e.message)
    }
  }

  async function handleDeleteDashboard(id) {
    if (!window.confirm('Delete this custom dashboard?')) return
    try {
      await fetch(`${apiBase}/api/custom-dashboards/${id}`, { method: 'DELETE' })
      const filtered = dashboards.filter(d => d.id !== id)
      setDashboards(filtered)
      if (filtered.length > 0) setActiveDashId(filtered[0].id)
      setNotice('Dashboard deleted.')
    } catch (e) {
      setNotice(e.message)
    }
  }

  function toggleWidgetType(type) {
    if (selectedWidgets.includes(type)) {
      if (selectedWidgets.length === 1) return
      setSelectedWidgets(selectedWidgets.filter(t => t !== type))
    } else {
      setSelectedWidgets([...selectedWidgets, type])
    }
  }

  const summary = aggregations?.summary || {}
  const clientBreakdown = aggregations?.client_breakdown || []
  const statusBreakdown = aggregations?.status_breakdown || []

  return (
    <section>
      <div className="custom-dash-header">
        <div>
          <span className="eyebrow">CUSTOM ANALYTICS MODULE</span>
          <h2 style={{ margin: '5px 0', fontFamily: 'Manrope' }}>Custom Data Dashboards</h2>
          <p style={{ margin: 0, fontSize: 13, color: '#64748b' }}>
            Build, configure, and isolate custom views without modifying default metrics.
          </p>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button className="refresh" onClick={loadData}>
            <RefreshCw size={15} /> Refresh Data
          </button>
          <button className="primary compact" onClick={() => setShowCreateModal(true)}>
            <PlusCircle size={15} /> New Dashboard
          </button>
        </div>
      </div>

      {notice && (
        <div className="notice" role="status">
          {notice}
          <button onClick={() => setNotice('')}>×</button>
        </div>
      )}

      {/* AI Insights Banner */}
      {insights?.insights?.length > 0 && (
        <div
          style={{
            background: 'linear-gradient(135deg, #17263f, #233b63)',
            color: '#fff',
            borderRadius: 12,
            padding: '16px 20px',
            marginBottom: 20,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 15
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div
              style={{
                width: 38,
                height: 38,
                borderRadius: 10,
                background: 'rgba(255,255,255,0.12)',
                display: 'grid',
                placeItems: 'center',
                color: '#60a5fa'
              }}
            >
              <Sparkles size={20} />
            </div>
            <div>
              <b style={{ fontSize: 13, display: 'block' }}>
                AI Insight: {insights.insights[0].title}
              </b>
              <span style={{ fontSize: 12, color: '#cbd5e1' }}>
                {insights.insights[0].message}
              </span>
            </div>
          </div>
          <div style={{ textAlign: 'right', minWidth: 120 }}>
            <small style={{ color: '#94a3b8', display: 'block', fontSize: 10 }}>
              Collection Health
            </small>
            <b style={{ fontSize: 18, color: '#34d399' }}>
              {insights.realization_rate}% Realized
            </b>
          </div>
        </div>
      )}

      {/* Dashboard Selection Tabs */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #e2e8f0', paddingBottom: 12 }}>
        <div className="dash-selector">
          {dashboards.map(d => (
            <button
              key={d.id}
              className={`dash-tab-btn ${d.id === activeDashId ? 'active' : ''}`}
              onClick={() => setActiveDashId(d.id)}
            >
              {d.title}
            </button>
          ))}
        </div>
        {currentDashboard && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <small style={{ color: '#64748b' }}>{currentDashboard.description}</small>
            <button
              style={{ background: 'transparent', border: 'none', color: '#ef4444', cursor: 'pointer' }}
              onClick={() => handleDeleteDashboard(currentDashboard.id)}
              title="Delete this custom dashboard"
            >
              <Trash2 size={16} />
            </button>
          </div>
        )}
      </div>

      {/* Dynamic Widget Grid for Current Custom Dashboard */}
      {currentDashboard && (
        <div className="dash-grid">
          {/* Widget: Financial Velocity */}
          <div className="dash-widget-card">
            <div className="dash-widget-header">
              <h4>Financial Realization & Target Rate</h4>
              <TrendingUp size={18} color="#3b82f6" />
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
              <span style={{ fontSize: 12, color: '#64748b' }}>Cash Collected vs Billed</span>
              <b style={{ fontSize: 12, color: '#1e293b' }}>{summary.realization_rate || 0}%</b>
            </div>
            <div className="progress-bar-bg">
              <div
                className="progress-bar-fill"
                style={{ width: `${Math.min(summary.realization_rate || 0, 100)}%` }}
              />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 16 }}>
              <div style={{ background: '#f8fafc', padding: 10, borderRadius: 8 }}>
                <small style={{ color: '#64748b', fontSize: 11 }}>Total Billed</small>
                <div style={{ fontWeight: 800, fontSize: 15, color: '#1e293b' }}>
                  {money(summary.total_billed)}
                </div>
              </div>
              <div style={{ background: '#f8fafc', padding: 10, borderRadius: 8 }}>
                <small style={{ color: '#64748b', fontSize: 11 }}>Average Invoice</small>
                <div style={{ fontWeight: 800, fontSize: 15, color: '#1e293b' }}>
                  {money(summary.avg_invoice)}
                </div>
              </div>
            </div>
          </div>

          {/* Widget: Customer Revenue Breakdown */}
          <div className="dash-widget-card">
            <div className="dash-widget-header">
              <h4>Top Clients by Revenue Volume</h4>
              <Users size={18} color="#3b82f6" />
            </div>
            {clientBreakdown.length === 0 ? (
              <p style={{ color: '#94a3b8', fontSize: 12 }}>No client billing history yet.</p>
            ) : (
              <div>
                {clientBreakdown.slice(0, 4).map((c, idx) => (
                  <div key={idx} className="client-rank-row">
                    <div>
                      <b>{c.customer}</b>
                      <small style={{ color: '#94a3b8' }}>
                        {c.count} invoice{c.count > 1 ? 's' : ''} ({money(c.paid)} paid)
                      </small>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <b style={{ color: '#1e293b' }}>{money(c.total)}</b>
                      {c.pending > 0 && (
                        <small style={{ color: '#ea580c', display: 'block' }}>
                          {money(c.pending)} pending
                        </small>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Widget: Status Distribution */}
          <div className="dash-widget-card">
            <div className="dash-widget-header">
              <h4>Workflow Status Breakdown</h4>
              <PieChart size={18} color="#3b82f6" />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {statusBreakdown.map((s, idx) => (
                <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span
                      style={{
                        width: 10,
                        height: 10,
                        borderRadius: '50%',
                        background:
                          s.status === 'Paid'
                            ? '#10b981'
                            : s.status === 'Approved'
                            ? '#3b82f6'
                            : '#f59e0b'
                      }}
                    />
                    <span style={{ fontSize: 12, color: '#334155' }}>{s.status}</span>
                  </div>
                  <div style={{ textAlign: 'right', fontSize: 12 }}>
                    <b>{s.count}</b> ({money(s.amount)})
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Widget: Aging Receivables Watchlist */}
          <div className="dash-widget-card">
            <div className="dash-widget-header">
              <h4>Receivables & Attention Watchlist</h4>
              <AlertCircle size={18} color="#ea580c" />
            </div>
            {summary.total_pending === 0 ? (
              <div style={{ textAlign: 'center', padding: '20px 0', color: '#10b981' }}>
                <CheckCircle2 size={32} style={{ margin: '0 auto 8px', display: 'block' }} />
                <b>Zero Overdue Invoices</b>
                <p style={{ fontSize: 11, color: '#64748b', margin: 0 }}>All accounts are settled!</p>
              </div>
            ) : (
              <div>
                <p style={{ fontSize: 12, color: '#64748b', margin: '0 0 10px 0' }}>
                  Clients with pending balances requiring follow-up:
                </p>
                {clientBreakdown
                  .filter(c => c.pending > 0)
                  .map((c, idx) => (
                    <div key={idx} className="client-rank-row">
                      <div>
                        <b>{c.customer}</b>
                        <small style={{ color: '#ea580c' }}>Awaiting payment</small>
                      </div>
                      <b style={{ color: '#ea580c' }}>{money(c.pending)}</b>
                    </div>
                  ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modal: Create Custom Dashboard */}
      {showCreateModal && (
        <div className="modal-overlay" onClick={() => setShowCreateModal(false)}>
          <div className="modal-box" onClick={e => e.stopPropagation()}>
            <h3 style={{ margin: '0 0 10px 0', fontFamily: 'Manrope' }}>Create Custom Dashboard</h3>
            <p style={{ fontSize: 12, color: '#64748b', margin: '0 0 16px 0' }}>
              Configure an isolated view tailored to your specific monitoring requirements.
            </p>
            <form onSubmit={handleCreateDashboard}>
              <div style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: '#475569', display: 'block', marginBottom: 4 }}>
                  Dashboard Name
                </label>
                <input
                  style={{ width: '100%', padding: '9px 12px', border: '1px solid #cbd5e1', borderRadius: 8, fontSize: 12 }}
                  placeholder="e.g. Q4 Growth & Collections"
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  required
                />
              </div>
              <div style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: '#475569', display: 'block', marginBottom: 4 }}>
                  Description (Optional)
                </label>
                <input
                  style={{ width: '100%', padding: '9px 12px', border: '1px solid #cbd5e1', borderRadius: 8, fontSize: 12 }}
                  placeholder="e.g. Dedicated focus on retainers and pending wire transfers"
                  value={newDesc}
                  onChange={e => setNewDesc(e.target.value)}
                />
              </div>

              <div style={{ marginBottom: 18 }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: '#475569', display: 'block', marginBottom: 6 }}>
                  Include Widgets
                </label>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                  {[
                    { id: 'metric', label: 'Financial Velocity' },
                    { id: 'customer_breakdown', label: 'Top Clients by Volume' },
                    { id: 'status_chart', label: 'Status Distribution' },
                    { id: 'aging_summary', label: 'Aging Receivables' }
                  ].map(w => (
                    <label
                      key={w.id}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: 8,
                        fontSize: 12,
                        background: '#f8fafc',
                        padding: '8px 10px',
                        borderRadius: 6,
                        cursor: 'pointer'
                      }}
                    >
                      <input
                        type="checkbox"
                        checked={selectedWidgets.includes(w.id)}
                        onChange={() => toggleWidgetType(w.id)}
                      />
                      <span>{w.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
                <button
                  type="button"
                  style={{ background: '#f1f5f9', border: 'none', padding: '9px 14px', borderRadius: 8, fontSize: 12 }}
                  onClick={() => setShowCreateModal(false)}
                >
                  Cancel
                </button>
                <button type="submit" className="primary compact" disabled={!newTitle.trim()}>
                  Save Dashboard
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  )
}

