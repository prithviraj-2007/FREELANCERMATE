import { useState, useEffect } from 'react'
import {
  ShieldAlert,
  PlusCircle,
  Clock3,
  CheckCircle2,
  AlertTriangle,
  UserCheck,
  Mail,
  PhoneCall,
  Calendar,
  Trash2,
  RefreshCw,
  FolderOpen
} from 'lucide-react'

const money = n =>
  new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2
  }).format(Number(n || 0))

export default function ManagementSupport({ apiBase }) {
  const [subTab, setSubTab] = useState('tickets') // 'tickets' | 'clients'
  const [tickets, setTickets] = useState([])
  const [clients, setClients] = useState([])
  const [overview, setOverview] = useState({ total_tickets: 0, open_tickets: 0, urgent_tickets: 0 })
  const [loading, setLoading] = useState(false)
  const [notice, setNotice] = useState('')

  // Modals
  const [showTicketModal, setShowTicketModal] = useState(false)
  const [newTicket, setNewTicket] = useState({
    title: '',
    client_name: '',
    category: 'Invoice Clarification',
    priority: 'Medium',
    notes: ''
  })

  const [showLogModal, setShowLogModal] = useState(false)
  const [logClientName, setLogClientName] = useState('')
  const [newLog, setNewLog] = useState({
    activity_type: 'Reminder',
    details: '',
    follow_up_date: '',
    contact_email: ''
  })

  async function loadData() {
    setLoading(true)
    try {
      const [tRes, cRes, oRes] = await Promise.all([
        fetch(`${apiBase}/api/management/tickets`).then(r => r.json()),
        fetch(`${apiBase}/api/management/clients`).then(r => r.json()),
        fetch(`${apiBase}/api/management/overview`).then(r => r.json())
      ])
      setTickets(tRes)
      setClients(cRes)
      setOverview(oRes)
    } catch (e) {
      setNotice(`Failed to load management support data: ${e.message}`)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadData()
  }, [])

  async function handleCreateTicket(e) {
    e.preventDefault()
    if (!newTicket.title.trim() || !newTicket.client_name.trim()) return

    try {
      const res = await fetch(`${apiBase}/api/management/tickets`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newTicket)
      })
      const created = await res.json()
      setTickets([created, ...tickets])
      setShowTicketModal(false)
      setNewTicket({
        title: '',
        client_name: '',
        category: 'Invoice Clarification',
        priority: 'Medium',
        notes: ''
      })
      setNotice('Support ticket created.')
      loadData()
    } catch (e) {
      setNotice(e.message)
    }
  }

  async function handleStatusChange(ticketId, newStatus) {
    try {
      await fetch(`${apiBase}/api/management/tickets/${ticketId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      })
      setTickets(
        tickets.map(t => (t.id === ticketId ? { ...t, status: newStatus } : t))
      )
      setNotice(`Ticket #${ticketId} status updated to ${newStatus}.`)
    } catch (e) {
      setNotice(e.message)
    }
  }

  async function handleDeleteTicket(ticketId) {
    if (!window.confirm('Delete this ticket?')) return
    try {
      await fetch(`${apiBase}/api/management/tickets/${ticketId}`, { method: 'DELETE' })
      setTickets(tickets.filter(t => t.id !== ticketId))
      setNotice('Ticket deleted.')
    } catch (e) {
      setNotice(e.message)
    }
  }

  async function handleAddLog(e) {
    e.preventDefault()
    if (!newLog.details.trim()) return

    try {
      await fetch(`${apiBase}/api/management/clients/logs`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          client_name: logClientName,
          ...newLog
        })
      })
      setShowLogModal(false)
      setNewLog({ activity_type: 'Reminder', details: '', follow_up_date: '', contact_email: '' })
      setNotice(`Log recorded for ${logClientName}.`)
      loadData()
    } catch (e) {
      setNotice(e.message)
    }
  }

  const openTickets = tickets.filter(t => t.status === 'Open')
  const inProgressTickets = tickets.filter(t => t.status === 'In Progress' || t.status === 'Waiting on Client')
  const resolvedTickets = tickets.filter(t => t.status === 'Resolved')

  return (
    <section className="mgt-container">
      <div className="custom-dash-header">
        <div>
          <span className="eyebrow">MANAGEMENT &amp; CLIENT SUPPORT</span>
          <h2 style={{ margin: '5px 0', fontFamily: 'Manrope' }}>Support Workflow &amp; User Tracking</h2>
          <p style={{ margin: 0, fontSize: 13, color: '#64748b' }}>
            Coordinate dispute resolution, track client communications, and handle operational steps.
          </p>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button className="refresh" onClick={loadData}>
            <RefreshCw size={15} /> Refresh
          </button>
          <button className="primary compact" onClick={() => setShowTicketModal(true)}>
            <PlusCircle size={15} /> Create Ticket
          </button>
        </div>
      </div>

      {notice && (
        <div className="notice" role="status">
          {notice}
          <button onClick={() => setNotice('')}>×</button>
        </div>
      )}

      {/* Overview Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
        <div style={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: 10, padding: 14, display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 36, height: 36, borderRadius: 8, background: '#fee2e2', color: '#dc2626', display: 'grid', placeItems: 'center' }}>
            <AlertTriangle size={18} />
          </div>
          <div>
            <span style={{ fontSize: 11, color: '#64748b', display: 'block' }}>Urgent Attention</span>
            <b style={{ fontSize: 18, color: '#1e293b' }}>{overview.urgent_tickets} ticket{overview.urgent_tickets === 1 ? '' : 's'}</b>
          </div>
        </div>

        <div style={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: 10, padding: 14, display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 36, height: 36, borderRadius: 8, background: '#fef3c7', color: '#d97706', display: 'grid', placeItems: 'center' }}>
            <Clock3 size={18} />
          </div>
          <div>
            <span style={{ fontSize: 11, color: '#64748b', display: 'block' }}>Active Workflows</span>
            <b style={{ fontSize: 18, color: '#1e293b' }}>{overview.open_tickets} in queue</b>
          </div>
        </div>

        <div style={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: 10, padding: 14, display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 36, height: 36, borderRadius: 8, background: '#e0f2fe', color: '#0284c7', display: 'grid', placeItems: 'center' }}>
            <UserCheck size={18} />
          </div>
          <div>
            <span style={{ fontSize: 11, color: '#64748b', display: 'block' }}>Tracked Client Accounts</span>
            <b style={{ fontSize: 18, color: '#1e293b' }}>{clients.length} active</b>
          </div>
        </div>
      </div>

      {/* Sub-navigation Pills */}
      <div className="mgt-nav-pills">
        <button
          className={`mgt-pill ${subTab === 'tickets' ? 'active' : ''}`}
          onClick={() => setSubTab('tickets')}
        >
          Support Ticket Pipeline ({tickets.length})
        </button>
        <button
          className={`mgt-pill ${subTab === 'clients' ? 'active' : ''}`}
          onClick={() => setSubTab('clients')}
        >
          Client Relationship &amp; Activity Log ({clients.length})
        </button>
      </div>

      {/* Section 1: Ticket Workflow Pipeline */}
      {subTab === 'tickets' && (
        <div className="ticket-grid">
          {/* Column: Open */}
          <div className="ticket-col">
            <h4>
              <span>Open Tickets</span>
              <span style={{ background: '#cbd5e1', padding: '1px 7px', borderRadius: 10, fontSize: 11 }}>
                {openTickets.length}
              </span>
            </h4>
            {openTickets.length === 0 && (
              <small style={{ color: '#94a3b8', textAlign: 'center', padding: '15px 0' }}>No open tickets.</small>
            )}
            {openTickets.map(t => (
              <TicketCard
                key={t.id}
                ticket={t}
                onStatusChange={handleStatusChange}
                onDelete={handleDeleteTicket}
              />
            ))}
          </div>

          {/* Column: In Progress */}
          <div className="ticket-col">
            <h4>
              <span>In Progress / Follow-up</span>
              <span style={{ background: '#fde68a', color: '#b45309', padding: '1px 7px', borderRadius: 10, fontSize: 11 }}>
                {inProgressTickets.length}
              </span>
            </h4>
            {inProgressTickets.length === 0 && (
              <small style={{ color: '#94a3b8', textAlign: 'center', padding: '15px 0' }}>No items in progress.</small>
            )}
            {inProgressTickets.map(t => (
              <TicketCard
                key={t.id}
                ticket={t}
                onStatusChange={handleStatusChange}
                onDelete={handleDeleteTicket}
              />
            ))}
          </div>

          {/* Column: Resolved */}
          <div className="ticket-col">
            <h4>
              <span>Resolved</span>
              <span style={{ background: '#bbf7d0', color: '#15803d', padding: '1px 7px', borderRadius: 10, fontSize: 11 }}>
                {resolvedTickets.length}
              </span>
            </h4>
            {resolvedTickets.length === 0 && (
              <small style={{ color: '#94a3b8', textAlign: 'center', padding: '15px 0' }}>No resolved tickets.</small>
            )}
            {resolvedTickets.map(t => (
              <TicketCard
                key={t.id}
                ticket={t}
                onStatusChange={handleStatusChange}
                onDelete={handleDeleteTicket}
              />
            ))}
          </div>
        </div>
      )}

      {/* Section 2: Client Relationship Tracker */}
      {subTab === 'clients' && (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Client Name</th>
                <th>Payment Reliability</th>
                <th>Total Billed</th>
                <th>Pending Balance</th>
                <th>Recent Logs</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {clients.map((c, idx) => (
                <tr key={idx}>
                  <td>
                    <b>{c.client_name}</b>
                    <small>{c.invoices_count} invoice(s)</small>
                  </td>
                  <td>
                    <span
                      style={{
                        padding: '4px 8px',
                        borderRadius: 12,
                        fontSize: 10,
                        fontWeight: 700,
                        background:
                          c.reliability.startsWith('High')
                            ? '#dcfce7'
                            : c.reliability.startsWith('Moderate')
                            ? '#fef9c3'
                            : '#fee2e2',
                        color:
                          c.reliability.startsWith('High')
                            ? '#166534'
                            : c.reliability.startsWith('Moderate')
                            ? '#854d0e'
                            : '#991b1b'
                      }}
                    >
                      {c.reliability} ({c.paid_ratio}%)
                    </span>
                  </td>
                  <td className="amount">{money(c.total_billed)}</td>
                  <td className="amount" style={{ color: c.pending_amount > 0 ? '#dc2626' : '#166534' }}>
                    {money(c.pending_amount)}
                  </td>
                  <td>
                    {c.logs?.length > 0 ? (
                      <div>
                        <b style={{ fontSize: 11 }}>
                          {c.logs[0].activity_type}: {c.logs[0].details.slice(0, 35)}…
                        </b>
                        {c.logs[0].follow_up_date && (
                          <small style={{ color: '#64748b' }}>
                            Next Follow-up: {c.logs[0].follow_up_date}
                          </small>
                        )}
                      </div>
                    ) : (
                      <small style={{ color: '#94a3b8' }}>No logs recorded</small>
                    )}
                  </td>
                  <td>
                    <button
                      className="primary compact"
                      style={{ padding: '5px 9px', fontSize: 11 }}
                      onClick={() => {
                        setLogClientName(c.client_name)
                        setShowLogModal(true)
                      }}
                    >
                      + Log Activity
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal: New Support Ticket */}
      {showTicketModal && (
        <div className="modal-overlay" onClick={() => setShowTicketModal(false)}>
          <div className="modal-box" onClick={e => e.stopPropagation()}>
            <h3 style={{ margin: '0 0 10px 0', fontFamily: 'Manrope' }}>Create Management Ticket</h3>
            <form onSubmit={handleCreateTicket}>
              <div style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: '#475569', display: 'block', marginBottom: 4 }}>
                  Ticket Title
                </label>
                <input
                  style={{ width: '100%', padding: '9px 12px', border: '1px solid #cbd5e1', borderRadius: 8, fontSize: 12 }}
                  placeholder="e.g. Scope dispute regarding Phase 2 assets"
                  value={newTicket.title}
                  onChange={e => setNewTicket({ ...newTicket, title: e.target.value })}
                  required
                />
              </div>
              <div style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: '#475569', display: 'block', marginBottom: 4 }}>
                  Client Name
                </label>
                <input
                  style={{ width: '100%', padding: '9px 12px', border: '1px solid #cbd5e1', borderRadius: 8, fontSize: 12 }}
                  placeholder="e.g. Arun"
                  value={newTicket.client_name}
                  onChange={e => setNewTicket({ ...newTicket, client_name: e.target.value })}
                  required
                />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 12 }}>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 700, color: '#475569', display: 'block', marginBottom: 4 }}>
                    Category
                  </label>
                  <select
                    style={{ width: '100%', padding: '9px 12px', border: '1px solid #cbd5e1', borderRadius: 8, fontSize: 12 }}
                    value={newTicket.category}
                    onChange={e => setNewTicket({ ...newTicket, category: e.target.value })}
                  >
                    <option value="Invoice Clarification">Invoice Clarification</option>
                    <option value="Payment Dispute">Payment Dispute</option>
                    <option value="Contract Review">Contract Review</option>
                    <option value="General Support">General Support</option>
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 700, color: '#475569', display: 'block', marginBottom: 4 }}>
                    Priority
                  </label>
                  <select
                    style={{ width: '100%', padding: '9px 12px', border: '1px solid #cbd5e1', borderRadius: 8, fontSize: 12 }}
                    value={newTicket.priority}
                    onChange={e => setNewTicket({ ...newTicket, priority: e.target.value })}
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                    <option value="Urgent">Urgent</option>
                  </select>
                </div>
              </div>
              <div style={{ marginBottom: 16 }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: '#475569', display: 'block', marginBottom: 4 }}>
                  Action Notes &amp; Next Steps
                </label>
                <textarea
                  rows="3"
                  style={{ width: '100%', padding: '9px 12px', border: '1px solid #cbd5e1', borderRadius: 8, fontSize: 12 }}
                  placeholder="Provide context on what needs resolution…"
                  value={newTicket.notes}
                  onChange={e => setNewTicket({ ...newTicket, notes: e.target.value })}
                />
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
                <button
                  type="button"
                  style={{ background: '#f1f5f9', border: 'none', padding: '9px 14px', borderRadius: 8, fontSize: 12 }}
                  onClick={() => setShowTicketModal(false)}
                >
                  Cancel
                </button>
                <button type="submit" className="primary compact">
                  Save Ticket
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Log Client Activity */}
      {showLogModal && (
        <div className="modal-overlay" onClick={() => setShowLogModal(false)}>
          <div className="modal-box" onClick={e => e.stopPropagation()}>
            <h3 style={{ margin: '0 0 10px 0', fontFamily: 'Manrope' }}>
              Log Activity for {logClientName}
            </h3>
            <form onSubmit={handleAddLog}>
              <div style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: '#475569', display: 'block', marginBottom: 4 }}>
                  Activity Type
                </label>
                <select
                  style={{ width: '100%', padding: '9px 12px', border: '1px solid #cbd5e1', borderRadius: 8, fontSize: 12 }}
                  value={newLog.activity_type}
                  onChange={e => setNewLog({ ...newLog, activity_type: e.target.value })}
                >
                  <option value="Reminder">Reminder Sent</option>
                  <option value="Phone Call">Phone Call</option>
                  <option value="Meeting">Meeting / Check-in</option>
                  <option value="Dispute Note">Dispute / Issue Note</option>
                </select>
              </div>
              <div style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: '#475569', display: 'block', marginBottom: 4 }}>
                  Follow-up Date (Optional)
                </label>
                <input
                  type="date"
                  style={{ width: '100%', padding: '9px 12px', border: '1px solid #cbd5e1', borderRadius: 8, fontSize: 12 }}
                  value={newLog.follow_up_date}
                  onChange={e => setNewLog({ ...newLog, follow_up_date: e.target.value })}
                />
              </div>
              <div style={{ marginBottom: 16 }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: '#475569', display: 'block', marginBottom: 4 }}>
                  Details &amp; Outcome
                </label>
                <textarea
                  rows="3"
                  style={{ width: '100%', padding: '9px 12px', border: '1px solid #cbd5e1', borderRadius: 8, fontSize: 12 }}
                  placeholder="Record summary of conversation or email sent…"
                  value={newLog.details}
                  onChange={e => setNewLog({ ...newLog, details: e.target.value })}
                  required
                />
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
                <button
                  type="button"
                  style={{ background: '#f1f5f9', border: 'none', padding: '9px 14px', borderRadius: 8, fontSize: 12 }}
                  onClick={() => setShowLogModal(false)}
                >
                  Cancel
                </button>
                <button type="submit" className="primary compact">
                  Save Log Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  )
}

function TicketCard({ ticket, onStatusChange, onDelete }) {
  const badgeClass =
    ticket.priority === 'Urgent'
      ? 'badge-urgent'
      : ticket.priority === 'High'
      ? 'badge-high'
      : ticket.priority === 'Medium'
      ? 'badge-medium'
      : 'badge-low'

  return (
    <div className="ticket-card">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 4 }}>
        <b style={{ fontSize: 12 }}>{ticket.title}</b>
        <button
          style={{ background: 'transparent', border: 'none', color: '#94a3b8', cursor: 'pointer', padding: 0 }}
          onClick={() => onDelete(ticket.id)}
          title="Delete ticket"
        >
          <Trash2 size={13} />
        </button>
      </div>
      <div style={{ marginBottom: 6 }}>
        <span className={`ticket-badge ${badgeClass}`}>{ticket.priority}</span>
        <small style={{ color: '#64748b', fontSize: 10 }}>Client: {ticket.client_name}</small>
      </div>
      {ticket.notes && (
        <p style={{ margin: '4px 0 8px 0', fontSize: 11, color: '#475569', lineHeight: 1.4 }}>
          {ticket.notes}
        </p>
      )}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 8, borderTop: '1px dashed #e2e8f0', paddingTop: 6 }}>
        <small style={{ color: '#94a3b8', fontSize: 10 }}>{ticket.category}</small>
        <div style={{ display: 'flex', gap: 4 }}>
          {ticket.status === 'Open' && (
            <button
              style={{ background: '#fef3c7', border: '1px solid #fde68a', borderRadius: 4, padding: '3px 6px', fontSize: 9, cursor: 'pointer', color: '#b45309' }}
              onClick={() => onStatusChange(ticket.id, 'In Progress')}
            >
              Start Progress →
            </button>
          )}
          {ticket.status !== 'Resolved' && (
            <button
              style={{ background: '#dcfce7', border: '1px solid #bbf7d0', borderRadius: 4, padding: '3px 6px', fontSize: 9, cursor: 'pointer', color: '#15803d' }}
              onClick={() => onStatusChange(ticket.id, 'Resolved')}
            >
              Resolve ✓
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

