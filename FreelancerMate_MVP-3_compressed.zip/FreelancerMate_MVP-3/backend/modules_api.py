import os
import json
import re
from datetime import datetime
from typing import Optional, List, Dict, Any
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import func

from main import SessionLocal, Invoice
from modules_db import CustomDashboard, SupportTicket, ClientLog

router = APIRouter(prefix="/api", tags=["Advanced Modules"])

# ==========================================
# Pydantic Schemas for New Features
# ==========================================

class AiChatMessage(BaseModel):
    message: str = Field(min_length=1, max_length=2000)
    history: Optional[List[Dict[str, str]]] = []

class CustomDashboardCreate(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    description: Optional[str] = Field(default="", max_length=255)
    widgets: List[Dict[str, Any]] = Field(default_factory=list)

class CustomDashboardUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    widgets: Optional[List[Dict[str, Any]]] = None

class SupportTicketCreate(BaseModel):
    title: str = Field(min_length=2, max_length=200)
    client_name: str = Field(min_length=1, max_length=120)
    category: Optional[str] = "Invoice Clarification"
    priority: Optional[str] = "Medium"
    notes: Optional[str] = ""

class SupportTicketStatusUpdate(BaseModel):
    status: str = Field(pattern="^(Open|In Progress|Waiting on Client|Resolved)$")

class ClientLogCreate(BaseModel):
    client_name: str = Field(min_length=1, max_length=120)
    contact_email: Optional[str] = None
    activity_type: str = Field(default="Reminder")
    details: str = Field(min_length=2, max_length=1000)
    follow_up_date: Optional[str] = None


# ==========================================
# Feature 1: AI Assist Module Endpoints
# ==========================================

def get_live_financial_context(db) -> Dict[str, Any]:
    """Extracts live context from invoices for AI understanding."""
    invoices = db.query(Invoice).all()
    total_invoices = len(invoices)
    paid_sum = sum(x.amount for x in invoices if x.status == "Paid")
    pending_sum = sum(x.amount for x in invoices if x.status != "Paid")
    paid_count = sum(1 for x in invoices if x.status == "Paid")
    pending_count = sum(1 for x in invoices if x.status != "Paid")
    
    clients = {}
    for inv in invoices:
        if inv.customer not in clients:
            clients[inv.customer] = {"total": 0.0, "paid": 0.0, "pending": 0.0, "count": 0}
        clients[inv.customer]["total"] += inv.amount
        clients[inv.customer]["count"] += 1
        if inv.status == "Paid":
            clients[inv.customer]["paid"] += inv.amount
        else:
            clients[inv.customer]["pending"] += inv.amount

    recent = [
        {"customer": x.customer, "service": x.service, "amount": x.amount, "status": x.status, "due_date": x.due_date}
        for x in sorted(invoices, key=lambda i: i.id, reverse=True)[:5]
    ]

    return {
        "total_earnings": paid_sum,
        "pending_receivables": pending_sum,
        "total_invoices": total_invoices,
        "paid_count": paid_count,
        "pending_count": pending_count,
        "client_summary": clients,
        "recent_invoices": recent
    }

@router.post("/ai/assistant")
def chat_with_assistant(data: AiChatMessage):
    """
    AI assistant interface for user support, payment reminder drafts,
    and financial insights using live database context.
    """
    db = SessionLocal()
    try:
        context = get_live_financial_context(db)
        user_query = data.message.strip()
        api_key = os.getenv("GEMINI_API_KEY")

        # Try Gemini API if key is present
        if api_key:
            try:
                from google import genai
                client = genai.Client(api_key=api_key)
                system_context = (
                    "You are FreelancerMate AI, a smart financial assistant and business advisor for freelancers.\n"
                    f"Current financial status: Total Earnings Paid: INR {context['total_earnings']:,.2f}, "
                    f"Pending Receivables: INR {context['pending_receivables']:,.2f}, "
                    f"Total Invoices: {context['total_invoices']} ({context['paid_count']} paid, {context['pending_count']} pending).\n"
                    f"Clients breakdown: {json.dumps(context['client_summary'])}\n"
                    f"Recent invoices: {json.dumps(context['recent_invoices'])}\n"
                    "Provide helpful, concise, actionable advice. If asked to draft an email or reminder, format it ready to copy."
                )
                response = client.models.generate_content(
                    model=os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
                    contents=f"{system_context}\n\nUser Question: {user_query}"
                )
                return {
                    "reply": response.text.strip(),
                    "source": "gemini",
                    "context_snapshot": {
                        "earnings": context["total_earnings"],
                        "pending": context["pending_receivables"]
                    }
                }
            except Exception as e:
                # Fallback to local intelligent assistant if external call fails
                pass

        # Contextual Intelligent Fallback Engine
        q = user_query.lower()
        earnings = f"₹{context['total_earnings']:,.2f}"
        pending = f"₹{context['pending_receivables']:,.2f}"
        
        if any(w in q for w in ["draft", "reminder", "email", "message"]):
            # Find client name if mentioned
            matched_client = None
            for c in context["client_summary"].keys():
                if c.lower() in q:
                    matched_client = c
                    break
            client_name = matched_client or "Client"
            pending_amt = context["client_summary"].get(matched_client, {}).get("pending", 0) if matched_client else context["pending_receivables"]
            amt_text = f"₹{pending_amt:,.2f}" if pending_amt > 0 else "the outstanding amount"

            reply = (
                f"Here is a professional payment reminder ready to send to **{client_name}**:\n\n"
                f"---\n"
                f"**Subject:** Follow-up: Invoice status for recent services\n\n"
                f"Hi {client_name},\n\n"
                f"Hope you are having a productive week! Just checking in regarding the recent invoice for {amt_text}.\n\n"
                f"Could you please confirm if this is on schedule for processing? Let me know if you need any additional details, receipts, or bank coordinates.\n\n"
                f"Thank you for your partnership!\n\n"
                f"Best regards,\n"
                f"[Your Name]\n"
                f"---"
            )
        elif any(w in q for w in ["earning", "revenue", "income", "how much made", "total"]):
            reply = (
                f"📊 **Financial Snapshot:**\n"
                f"• **Received Earnings:** {earnings} across {context['paid_count']} paid invoices.\n"
                f"• **Pending Receivables:** {pending} across {context['pending_count']} pending invoices.\n"
                f"• **Total Billed:** ₹{(context['total_earnings'] + context['pending_receivables']):,.2f}."
            )
        elif any(w in q for w in ["pending", "owe", "due", "unpaid"]):
            pending_clients = [
                f"• **{c}**: ₹{data['pending']:,.2f}"
                for c, data in context["client_summary"].items() if data["pending"] > 0
            ]
            if pending_clients:
                reply = (
                    f"⏳ You have **{pending}** currently awaiting payment:\n" +
                    "\n".join(pending_clients) +
                    "\n\n*Tip: You can use the Management Support tool or ask me to draft a reminder email for any client!*"
                )
            else:
                reply = "🎉 Great news! You have zero pending invoices right now. All recorded invoices have been marked as paid."
        elif any(w in q for w in ["client", "customer"]):
            client_list = [
                f"• **{c}**: Billed ₹{d['total']:,.2f} ({d['count']} invoices)"
                for c, d in context["client_summary"].items()
            ]
            reply = f"👥 **Your Clients ({len(context['client_summary'])} total):**\n" + (
                "\n".join(client_list) if client_list else "No clients on record yet."
            )
        elif any(w in q for w in ["help", "feature", "what can you do", "support"]):
            reply = (
                "👋 I can assist you with:\n"
                "1. **Payment Reminders:** Ask me *'Draft a polite reminder for Arun'*.\n"
                "2. **Financial Insights:** Ask *'How much is pending?'* or *'Who owes me money?'*.\n"
                "3. **Custom Dashboards:** Head over to the **Custom Analytics** tab to build custom metric boards.\n"
                "4. **Client Management:** Check the **Management & Support** tab to track communication logs and dispute tickets."
            )
        else:
            reply = (
                f"Got it! Based on your current portfolio, your business has **{earnings}** collected and **{pending}** pending.\n\n"
                "Would you like me to draft a reminder email, break down your revenue by client, or help you track a new support task?"
            )

        return {
            "reply": reply,
            "source": "local_ai_engine",
            "context_snapshot": {
                "earnings": context["total_earnings"],
                "pending": context["pending_receivables"]
            }
        }
    finally:
        db.close()


@router.get("/ai/insights")
def get_ai_insights():
    """Generates automated business health metrics and actionable recommendations."""
    db = SessionLocal()
    try:
        invoices = db.query(Invoice).all()
        paid_sum = sum(x.amount for x in invoices if x.status == "Paid")
        pending_sum = sum(x.amount for x in invoices if x.status != "Paid")
        total_billed = paid_sum + pending_sum
        realization_rate = round((paid_sum / total_billed * 100), 1) if total_billed > 0 else 0

        # Concentration check
        clients = {}
        for x in invoices:
            clients[x.customer] = clients.get(x.customer, 0) + x.amount
        
        top_client = max(clients.items(), key=lambda c: c[1]) if clients else ("None", 0)
        concentration_pct = round((top_client[1] / total_billed * 100), 1) if total_billed > 0 else 0

        insights = []
        if realization_rate < 60 and pending_sum > 0:
            insights.append({
                "type": "warning",
                "title": "Low Collection Velocity",
                "message": f"Only {realization_rate}% of billed revenue is collected. Consider sending batch reminders to clear pending balances."
            })
        elif realization_rate >= 80:
            insights.append({
                "type": "success",
                "title": "Excellent Cash Realization",
                "message": f"Your collection rate is strong at {realization_rate}%. Healthy cash flow!"
            })

        if concentration_pct > 50:
            insights.append({
                "type": "info",
                "title": "Revenue Concentration Notice",
                "message": f"{top_client[0]} represents {concentration_pct}% of your total billing. Expanding client diversity will reduce cash flow risk."
            })

        if not insights:
            insights.append({
                "type": "info",
                "title": "Portfolio In Balance",
                "message": "Invoices and client accounts are flowing normally. Keep logging deliverables consistently."
            })

        return {
            "realization_rate": realization_rate,
            "top_client": top_client[0],
            "top_client_share": concentration_pct,
            "insights": insights
        }
    finally:
        db.close()


# ==========================================
# Feature 2: Data Dashboard Creation Endpoints
# ==========================================

@router.get("/custom-dashboards")
def list_custom_dashboards():
    """List all user-defined custom dashboards."""
    db = SessionLocal()
    try:
        items = db.query(CustomDashboard).order_by(CustomDashboard.created_at.desc()).all()
        result = []
        for d in items:
            try:
                widgets = json.loads(d.widgets_json) if d.widgets_json else []
            except Exception:
                widgets = []
            result.append({
                "id": d.id,
                "title": d.title,
                "description": d.description,
                "widgets": widgets,
                "widget_count": len(widgets),
                "created_at": d.created_at.isoformat() if d.created_at else None,
                "updated_at": d.updated_at.isoformat() if d.updated_at else None
            })
        return result
    finally:
        db.close()

@router.post("/custom-dashboards")
def create_custom_dashboard(data: CustomDashboardCreate):
    """Create a new custom dashboard with user-configured widgets."""
    db = SessionLocal()
    try:
        item = CustomDashboard(
            title=data.title.strip(),
            description=(data.description or "").strip(),
            widgets_json=json.dumps(data.widgets)
        )
        db.add(item)
        db.commit()
        db.refresh(item)
        return {
            "id": item.id,
            "title": item.title,
            "description": item.description,
            "widgets": data.widgets,
            "created_at": item.created_at.isoformat() if item.created_at else None
        }
    finally:
        db.close()

@router.get("/custom-dashboards/{dashboard_id}")
def get_custom_dashboard(dashboard_id: int):
    """Retrieve details and widget configuration for a specific custom dashboard."""
    db = SessionLocal()
    try:
        d = db.query(CustomDashboard).filter(CustomDashboard.id == dashboard_id).first()
        if not d:
            raise HTTPException(status_code=404, detail="Dashboard not found")
        try:
            widgets = json.loads(d.widgets_json) if d.widgets_json else []
        except Exception:
            widgets = []
        return {
            "id": d.id,
            "title": d.title,
            "description": d.description,
            "widgets": widgets,
            "created_at": d.created_at.isoformat() if d.created_at else None
        }
    finally:
        db.close()

@router.put("/custom-dashboards/{dashboard_id}")
def update_custom_dashboard(dashboard_id: int, data: CustomDashboardUpdate):
    """Update widget configuration or title of a custom dashboard."""
    db = SessionLocal()
    try:
        d = db.query(CustomDashboard).filter(CustomDashboard.id == dashboard_id).first()
        if not d:
            raise HTTPException(status_code=404, detail="Dashboard not found")
        if data.title is not None:
            d.title = data.title.strip()
        if data.description is not None:
            d.description = data.description.strip()
        if data.widgets is not None:
            d.widgets_json = json.dumps(data.widgets)
        d.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(d)
        return {"message": "Dashboard updated successfully", "id": d.id}
    finally:
        db.close()

@router.delete("/custom-dashboards/{dashboard_id}")
def delete_custom_dashboard(dashboard_id: int):
    """Delete a custom dashboard."""
    db = SessionLocal()
    try:
        d = db.query(CustomDashboard).filter(CustomDashboard.id == dashboard_id).first()
        if not d:
            raise HTTPException(status_code=404, detail="Dashboard not found")
        db.delete(d)
        db.commit()
        return {"message": "Custom dashboard deleted"}
    finally:
        db.close()

@router.get("/analytics/aggregations")
def get_analytics_aggregations():
    """Provides aggregated business data for dynamic custom dashboard widgets."""
    db = SessionLocal()
    try:
        invoices = db.query(Invoice).all()
        
        # 1. Client revenue breakdown
        clients: Dict[str, Dict[str, Any]] = {}
        for inv in invoices:
            c = inv.customer or "Unknown"
            if c not in clients:
                clients[c] = {"customer": c, "total": 0.0, "paid": 0.0, "pending": 0.0, "count": 0}
            clients[c]["total"] += inv.amount
            clients[c]["count"] += 1
            if inv.status == "Paid":
                clients[c]["paid"] += inv.amount
            else:
                clients[c]["pending"] += inv.amount
        client_breakdown = sorted(clients.values(), key=lambda x: x["total"], reverse=True)

        # 2. Status breakdown
        statuses = {"Pending Approval": {"count": 0, "amount": 0.0}, "Approved": {"count": 0, "amount": 0.0}, "Paid": {"count": 0, "amount": 0.0}}
        for inv in invoices:
            st = inv.status if inv.status in statuses else "Pending Approval"
            statuses[st]["count"] += 1
            statuses[st]["amount"] += inv.amount

        # 3. Summary metrics
        total_billed = sum(x.amount for x in invoices)
        total_paid = statuses["Paid"]["amount"]
        total_pending = statuses["Pending Approval"]["amount"] + statuses["Approved"]["amount"]
        avg_invoice = round(total_billed / len(invoices), 2) if invoices else 0.0
        realization_rate = round(total_paid / total_billed * 100, 1) if total_billed > 0 else 0.0

        return {
            "summary": {
                "total_billed": round(total_billed, 2),
                "total_paid": round(total_paid, 2),
                "total_pending": round(total_pending, 2),
                "avg_invoice": avg_invoice,
                "realization_rate": realization_rate,
                "total_invoices": len(invoices)
            },
            "client_breakdown": client_breakdown,
            "status_breakdown": [
                {"status": k, "count": v["count"], "amount": round(v["amount"], 2)}
                for k, v in statuses.items()
            ]
        }
    finally:
        db.close()


# ==========================================
# Feature 3: Management Support Tools Endpoints
# ==========================================

@router.get("/management/tickets")
def list_support_tickets(status: Optional[str] = None, priority: Optional[str] = None):
    """Retrieve support and client workflow tickets with optional filters."""
    db = SessionLocal()
    try:
        query = db.query(SupportTicket)
        if status:
            query = query.filter(SupportTicket.status == status)
        if priority:
            query = query.filter(SupportTicket.priority == priority)
        items = query.order_by(SupportTicket.created_at.desc()).all()
        return [
            {
                "id": t.id,
                "title": t.title,
                "client_name": t.client_name,
                "category": t.category,
                "priority": t.priority,
                "status": t.status,
                "notes": t.notes,
                "created_at": t.created_at.isoformat() if t.created_at else None,
                "updated_at": t.updated_at.isoformat() if t.updated_at else None
            }
            for t in items
        ]
    finally:
        db.close()

@router.post("/management/tickets")
def create_support_ticket(data: SupportTicketCreate):
    """Create a new support or follow-up ticket."""
    db = SessionLocal()
    try:
        t = SupportTicket(
            title=data.title.strip(),
            client_name=data.client_name.strip(),
            category=data.category or "Invoice Clarification",
            priority=data.priority or "Medium",
            status="Open",
            notes=(data.notes or "").strip()
        )
        db.add(t)
        db.commit()
        db.refresh(t)
        return {
            "id": t.id,
            "title": t.title,
            "client_name": t.client_name,
            "category": t.category,
            "priority": t.priority,
            "status": t.status,
            "notes": t.notes,
            "created_at": t.created_at.isoformat() if t.created_at else None
        }
    finally:
        db.close()

@router.patch("/management/tickets/{ticket_id}/status")
def update_ticket_status(ticket_id: int, data: SupportTicketStatusUpdate):
    """Update workflow status of a support ticket."""
    db = SessionLocal()
    try:
        t = db.query(SupportTicket).filter(SupportTicket.id == ticket_id).first()
        if not t:
            raise HTTPException(status_code=404, detail="Ticket not found")
        t.status = data.status
        t.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(t)
        return {"id": t.id, "status": t.status, "message": "Ticket status updated"}
    finally:
        db.close()

@router.delete("/management/tickets/{ticket_id}")
def delete_support_ticket(ticket_id: int):
    """Delete a support ticket."""
    db = SessionLocal()
    try:
        t = db.query(SupportTicket).filter(SupportTicket.id == ticket_id).first()
        if not t:
            raise HTTPException(status_code=404, detail="Ticket not found")
        db.delete(t)
        db.commit()
        return {"message": "Ticket deleted successfully"}
    finally:
        db.close()

@router.get("/management/clients")
def list_client_management_profiles():
    """List tracked clients, their financial reliability score, and activity history."""
    db = SessionLocal()
    try:
        invoices = db.query(Invoice).all()
        logs = db.query(ClientLog).order_by(ClientLog.created_at.desc()).all()
        
        clients: Dict[str, Dict[str, Any]] = {}
        for inv in invoices:
            c = inv.customer
            if c not in clients:
                clients[c] = {
                    "client_name": c,
                    "invoices_count": 0,
                    "total_billed": 0.0,
                    "pending_amount": 0.0,
                    "paid_amount": 0.0,
                    "logs": []
                }
            clients[c]["invoices_count"] += 1
            clients[c]["total_billed"] += inv.amount
            if inv.status == "Paid":
                clients[c]["paid_amount"] += inv.amount
            else:
                clients[c]["pending_amount"] += inv.amount

        # Attach activity logs
        for l in logs:
            if l.client_name in clients:
                clients[l.client_name]["logs"].append({
                    "id": l.id,
                    "activity_type": l.activity_type,
                    "details": l.details,
                    "follow_up_date": l.follow_up_date,
                    "created_at": l.created_at.isoformat() if l.created_at else None
                })

        # Calculate reliability score
        result = []
        for c, val in clients.items():
            billed = val["total_billed"]
            paid = val["paid_amount"]
            ratio = (paid / billed) if billed > 0 else 1.0
            if ratio >= 0.8:
                reliability = "High (Reliable)"
            elif ratio >= 0.4:
                reliability = "Moderate"
            else:
                reliability = "Attention Required"
            
            result.append({
                **val,
                "reliability": reliability,
                "paid_ratio": round(ratio * 100, 1)
            })

        return sorted(result, key=lambda x: x["total_billed"], reverse=True)
    finally:
        db.close()

@router.post("/management/clients/logs")
def add_client_activity_log(data: ClientLogCreate):
    """Add a communication log, call summary, or payment follow-up note."""
    db = SessionLocal()
    try:
        log = ClientLog(
            client_name=data.client_name.strip(),
            contact_email=data.contact_email,
            activity_type=data.activity_type or "Reminder",
            details=data.details.strip(),
            follow_up_date=data.follow_up_date
        )
        db.add(log)
        db.commit()
        db.refresh(log)
        return {
            "id": log.id,
            "client_name": log.client_name,
            "activity_type": log.activity_type,
            "details": log.details,
            "follow_up_date": log.follow_up_date,
            "created_at": log.created_at.isoformat() if log.created_at else None
        }
    finally:
        db.close()

@router.get("/management/overview")
def get_management_overview():
    """Provides high-level support and workflow metrics."""
    db = SessionLocal()
    try:
        total_tickets = db.query(SupportTicket).count()
        open_tickets = db.query(SupportTicket).filter(SupportTicket.status.in_(["Open", "In Progress"])).count()
        urgent_tickets = db.query(SupportTicket).filter(SupportTicket.priority == "Urgent").count()
        recent_logs = db.query(ClientLog).order_by(ClientLog.created_at.desc()).limit(5).all()

        return {
            "total_tickets": total_tickets,
            "open_tickets": open_tickets,
            "urgent_tickets": urgent_tickets,
            "recent_logs_count": len(recent_logs)
        }
    finally:
        db.close()

