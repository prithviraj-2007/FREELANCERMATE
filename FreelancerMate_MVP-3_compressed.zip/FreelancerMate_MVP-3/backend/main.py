import os, re
import base64
import json
from decimal import Decimal, InvalidOperation
from datetime import datetime, date
from typing import Optional
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, func, inspect, text
from sqlalchemy.orm import declarative_base, sessionmaker
from dotenv import load_dotenv

load_dotenv()
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./freelancermate.db")
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

class Invoice(Base):
    __tablename__ = "invoices"
    id = Column(Integer, primary_key=True, index=True)
    customer = Column(String, nullable=False)
    service = Column(String, nullable=False)
    amount = Column(Float, nullable=False)
    currency = Column(String, default="INR")
    status = Column(String, default="Pending Approval")
    created_at = Column(DateTime, default=datetime.utcnow)
    due_date = Column(String, nullable=True)
    paypal_invoice_id = Column(String, nullable=True)
    paypal_order_id = Column(String, nullable=True)

Base.metadata.create_all(bind=engine)
with engine.begin() as connection:
    invoice_columns = {column["name"] for column in inspect(engine).get_columns("invoices")}
    if "paypal_order_id" not in invoice_columns:
        connection.execute(text("ALTER TABLE invoices ADD COLUMN paypal_order_id VARCHAR"))

app = FastAPI(title="FreelancerMate API", version="1.0.0")
additional_origins = [
    origin.strip().rstrip("/")
    for origin in os.getenv("BACKEND_CORS_ORIGINS", "").split(",")
    if origin.strip()
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173", "http://127.0.0.1:5173",
        "http://localhost:5174", "http://127.0.0.1:5174",
        "http://localhost:3000", "http://127.0.0.1:3000",
        *additional_origins,
    ],
    allow_origin_regex=r"^https?://(localhost|127\.0\.0\.1)(:\d+)?$",
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"]
)

# Mount additive modules router (Isolated new endpoints)
from modules_api import router as addon_router
app.include_router(addon_router)

class InvoiceInput(BaseModel):
    customer: str = Field(min_length=1, max_length=120)
    service: str = Field(min_length=1, max_length=300)
    amount: float = Field(gt=0)
    due_date: Optional[str] = None

class PromptInput(BaseModel):
    prompt: str = Field(min_length=5, max_length=1000)

class PayPalCaptureInput(BaseModel):
    order_id: str = Field(min_length=1, max_length=64)

def paypal_settings():
    mode = os.getenv("PAYPAL_MODE", "sandbox").strip().lower()
    if mode not in {"sandbox", "live"}:
        raise HTTPException(status_code=503, detail="PAYPAL_MODE must be 'sandbox' or 'live'.")
    return {
        "mode": mode,
        "client_id": os.getenv("PAYPAL_CLIENT_ID", "").strip(),
        "client_secret": os.getenv("PAYPAL_CLIENT_SECRET", "").strip(),
        "currency": os.getenv("PAYPAL_CURRENCY", "INR").strip().upper(),
        "base_url": "https://api-m.sandbox.paypal.com" if mode == "sandbox" else "https://api-m.paypal.com",
    }

def paypal_is_configured(settings=None):
    settings = settings or paypal_settings()
    return bool(settings["client_id"] and settings["client_secret"])

def paypal_request(path, method="GET", payload=None, request_id=None):
    settings = paypal_settings()
    if not paypal_is_configured(settings):
        raise HTTPException(status_code=503, detail="PayPal is not configured on the server.")

    credentials = f'{settings["client_id"]}:{settings["client_secret"]}'.encode("utf-8")
    authorization = "Basic " + base64.b64encode(credentials).decode("ascii")
    token_request = Request(
        f'{settings["base_url"]}/v1/oauth2/token',
        data=urlencode({"grant_type": "client_credentials"}).encode("ascii"),
        headers={"Authorization": authorization, "Content-Type": "application/x-www-form-urlencoded"},
        method="POST",
    )
    try:
        with urlopen(token_request, timeout=20) as response:
            access_token = json.loads(response.read().decode("utf-8"))["access_token"]

        body = json.dumps(payload).encode("utf-8") if payload is not None else None
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
            "Prefer": "return=representation",
        }
        if request_id:
            headers["PayPal-Request-Id"] = request_id
        api_request = Request(
            f'{settings["base_url"]}{path}',
            data=body,
            headers=headers,
            method=method,
        )
        with urlopen(api_request, timeout=20) as response:
            response_body = response.read().decode("utf-8")
            return json.loads(response_body) if response_body else {}
    except HTTPError as error:
        provider_message = ""
        try:
            provider_error = json.loads(error.read().decode("utf-8"))
            provider_message = provider_error.get("message") or provider_error.get("name") or ""
        except (ValueError, AttributeError):
            pass
        message = f"PayPal returned HTTP {error.code}"
        if provider_message:
            message += f": {provider_message}"
        raise HTTPException(status_code=502, detail=message) from error
    except (URLError, TimeoutError, KeyError, ValueError) as error:
        raise HTTPException(status_code=502, detail="Unable to complete the PayPal request.") from error

def format_paypal_amount(amount):
    try:
        value = Decimal(str(amount))
        rounded = value.quantize(Decimal("0.01"))
        if value != rounded:
            raise HTTPException(status_code=422, detail="PayPal invoices must have at most two decimal places.")
        return format(rounded, "f")
    except InvalidOperation as error:
        raise HTTPException(status_code=422, detail="Invoice amount is invalid for PayPal.") from error

def find_invoice(db, invoice_id):
    item = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Invoice not found")
    return item

def validate_paypal_capture(item, paypal_order):
    if paypal_order.get("status") != "COMPLETED":
        raise HTTPException(status_code=409, detail="PayPal has not completed this payment.")

    captures = [
        capture
        for unit in paypal_order.get("purchase_units", [])
        for capture in (unit.get("payments", {}).get("captures", []) or [])
        if capture.get("status") == "COMPLETED"
    ]
    try:
        captured_total = sum(
            (Decimal(capture["amount"]["value"]) for capture in captures),
            Decimal("0"),
        ).quantize(Decimal("0.01"))
    except (KeyError, InvalidOperation) as error:
        raise HTTPException(status_code=502, detail="PayPal returned incomplete capture details.") from error

    expected_amount = Decimal(format_paypal_amount(item.amount))
    expected_currency = paypal_settings()["currency"]
    capture_currencies = {capture.get("amount", {}).get("currency_code") for capture in captures}
    if captured_total != expected_amount or capture_currencies != {expected_currency}:
        raise HTTPException(status_code=409, detail="PayPal's captured amount or currency does not match this invoice.")

def parse_invoice_prompt(prompt: str):
    # Optional Gemini integration; safe local parser is used when no key is configured.
    api_key = os.getenv("GEMINI_API_KEY")
    if api_key:
        try:
            from google import genai
            client = genai.Client(api_key=api_key)
            response = client.models.generate_content(
                model=os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
                contents=(
                    "Extract invoice fields from the user's request. Return ONLY JSON with "
                    "customer, service, amount. Amount must be a number in INR. "
                    "If a field is missing, use an empty string or 0. Request: " + prompt
                )
            )
            import json
            raw = response.text.strip().replace("```json", "").replace("```", "")
            data = json.loads(raw)
            if data.get("customer") and data.get("service") and float(data.get("amount", 0)) > 0:
                return {"customer": str(data["customer"]), "service": str(data["service"]),
                        "amount": float(data["amount"])}
        except Exception:
            pass

    # Basic offline fallback: extracts an amount and tries to identify "for CUSTOMER ... for SERVICE".
    amount_match = re.search(r"(?:₹|rs\.?|inr)?\s*([\d,]+(?:\.\d{1,2})?)", prompt, re.I)
    amount = float(amount_match.group(1).replace(",", "")) if amount_match else 0
    customer = ""
    service = ""
    m = re.search(r"\bfor\s+([A-Za-z][A-Za-z .'-]{0,50}?)\s+(?:for|of)\s+(.+?)(?:\s+(?:for|amount)\s+₹?[\d,]+.*)?$", prompt, re.I)
    if m:
        customer, service = m.group(1).strip(), m.group(2).strip(" .")
    else:
        # Alternative: "invoice to Arun, service logo design, amount 12000"
        cm = re.search(r"(?:to|customer)\s+([A-Za-z][A-Za-z .'-]{0,50})", prompt, re.I)
        sm = re.search(r"(?:service|work|for)\s*[:=]?\s*([A-Za-z][A-Za-z .'-]{1,100})", prompt, re.I)
        customer = cm.group(1).strip() if cm else ""
        service = sm.group(1).strip() if sm else ""
    return {"customer": customer, "service": service, "amount": amount}

@app.get("/")
def home():
    return {"message": "FreelancerMate API is running", "mode": "local MVP"}

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/ai/parse")
def ai_parse(data: PromptInput):
    result = parse_invoice_prompt(data.prompt)
    missing = [k for k in ("customer", "service", "amount") if not result.get(k)]
    return {"fields": result, "missing_fields": missing,
            "ai_enabled": bool(os.getenv("GEMINI_API_KEY"))}

@app.post("/invoices")
def create_invoice(data: InvoiceInput):
    db = SessionLocal()
    try:
        item = Invoice(customer=data.customer.strip(), service=data.service.strip(),
                       amount=data.amount, due_date=data.due_date)
        db.add(item); db.commit(); db.refresh(item)
        return invoice_dict(item)
    finally:
        db.close()

@app.get("/invoices")
def list_invoices():
    db = SessionLocal()
    try:
        items = db.query(Invoice).order_by(Invoice.created_at.desc()).all()
        return [invoice_dict(x) for x in items]
    finally:
        db.close()

@app.get("/invoices/{invoice_id}")
def get_invoice(invoice_id: int):
    db = SessionLocal()
    try:
        item = db.query(Invoice).filter(Invoice.id == invoice_id).first()
        if not item: raise HTTPException(404, "Invoice not found")
        return invoice_dict(item)
    finally:
        db.close()

@app.patch("/invoices/{invoice_id}/approve")
def approve_invoice(invoice_id: int):
    return update_status(invoice_id, "Approved")

@app.patch("/invoices/{invoice_id}/paid")
def mark_paid(invoice_id: int):
    if paypal_is_configured():
        raise HTTPException(
            status_code=409,
            detail="Manual payment marking is disabled while PayPal is configured. Use verified PayPal checkout.",
        )
    return update_status(invoice_id, "Paid")

@app.patch("/invoices/{invoice_id}/pending")
def mark_pending(invoice_id: int):
    return update_status(invoice_id, "Pending Approval")

@app.delete("/invoices/{invoice_id}")
def delete_invoice(invoice_id: int):
    db = SessionLocal()
    try:
        item = db.query(Invoice).filter(Invoice.id == invoice_id).first()
        if not item: raise HTTPException(404, "Invoice not found")
        if item.status == "Paid" or item.paypal_order_id:
            raise HTTPException(status_code=409, detail="Paid invoices and invoices with a PayPal order cannot be deleted.")
        db.delete(item); db.commit()
        return {"message": "Invoice deleted"}
    finally:
        db.close()

def update_status(invoice_id, status):
    db = SessionLocal()
    try:
        item = db.query(Invoice).filter(Invoice.id == invoice_id).first()
        if not item: raise HTTPException(404, "Invoice not found")
        if item.status == "Paid" and status != "Paid":
            raise HTTPException(status_code=409, detail="Paid invoices cannot be reopened.")
        item.status = status
        db.commit(); db.refresh(item)
        return invoice_dict(item)
    finally:
        db.close()

@app.get("/dashboard")
def dashboard():
    db = SessionLocal()
    try:
        all_items = db.query(Invoice).all()
        paid = sum(x.amount for x in all_items if x.status == "Paid")
        pending = sum(x.amount for x in all_items if x.status != "Paid")
        return {
            "total_invoices": len(all_items),
            "total_earnings": round(paid, 2),
            "pending_amount": round(pending, 2),
            "paid_count": sum(1 for x in all_items if x.status == "Paid"),
            "pending_count": sum(1 for x in all_items if x.status != "Paid")
        }
    finally:
        db.close()

@app.get("/paypal/config")
def get_paypal_config():
    settings = paypal_settings()
    return {
        "enabled": paypal_is_configured(settings),
        "client_id": settings["client_id"] if paypal_is_configured(settings) else None,
        "currency": settings["currency"],
        "mode": settings["mode"],
    }

@app.post("/invoices/{invoice_id}/paypal/order")
def create_paypal_order(invoice_id: int):
    settings = paypal_settings()
    if not paypal_is_configured(settings):
        raise HTTPException(status_code=503, detail="PayPal is not configured on the server.")

    db = SessionLocal()
    try:
        item = find_invoice(db, invoice_id)
        if item.status == "Paid":
            raise HTTPException(status_code=409, detail="This invoice has already been paid.")
        if item.status != "Approved":
            raise HTTPException(status_code=409, detail="Approve this invoice before starting PayPal checkout.")
        if (item.currency or "INR").upper() != settings["currency"]:
            raise HTTPException(status_code=409, detail="Invoice currency does not match PAYPAL_CURRENCY.")
        if item.paypal_order_id:
            return {"order_id": item.paypal_order_id}

        order = paypal_request(
            "/v2/checkout/orders",
            method="POST",
            payload={
                "intent": "CAPTURE",
                "purchase_units": [{
                    "reference_id": f"invoice-{item.id}",
                    "custom_id": str(item.id),
                    "description": f"{item.service[:120]} - {item.customer[:80]}",
                    "amount": {
                        "currency_code": settings["currency"],
                        "value": format_paypal_amount(item.amount),
                    },
                }],
            },
            request_id=f"invoice-{item.id}-order",
        )
        order_id = order.get("id")
        if not order_id:
            raise HTTPException(status_code=502, detail="PayPal did not return an order ID.")
        item.paypal_order_id = order_id
        db.commit()
        return {"order_id": order_id}
    finally:
        db.close()

@app.post("/invoices/{invoice_id}/paypal/capture")
def capture_paypal_order(invoice_id: int, data: PayPalCaptureInput):
    settings = paypal_settings()
    if not paypal_is_configured(settings):
        raise HTTPException(status_code=503, detail="PayPal is not configured on the server.")

    db = SessionLocal()
    try:
        item = find_invoice(db, invoice_id)
        if item.paypal_order_id != data.order_id:
            raise HTTPException(status_code=409, detail="PayPal order does not belong to this invoice.")
        if item.status == "Paid":
            return invoice_dict(item)
        if item.status != "Approved":
            raise HTTPException(status_code=409, detail="Only approved invoices can be paid through PayPal.")

        paypal_order = paypal_request(f"/v2/checkout/orders/{data.order_id}")
        if paypal_order.get("status") == "APPROVED":
            paypal_order = paypal_request(
                f"/v2/checkout/orders/{data.order_id}/capture",
                method="POST",
                payload={},
                request_id=f"invoice-{item.id}-capture",
            )
        validate_paypal_capture(item, paypal_order)
        item.status = "Paid"
        db.commit()
        db.refresh(item)
        return invoice_dict(item)
    finally:
        db.close()

def invoice_dict(x):
    return {
        "id": x.id, "customer": x.customer, "service": x.service,
        "amount": x.amount, "currency": x.currency, "status": x.status,
        "created_at": x.created_at.isoformat() if x.created_at else None,
        "due_date": x.due_date, "paypal_invoice_id": x.paypal_invoice_id,
        "paypal_order_id": x.paypal_order_id
    }

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8001))
    uvicorn.run("main:app", host="127.0.0.1", port=port, reload=True)
