import json
from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, Text
from main import Base, engine, SessionLocal

# ==========================================
# New Additive Database Models
# Existing tables (invoices) remain 100% intact
# ==========================================

class CustomDashboard(Base):
    __tablename__ = "custom_dashboards"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(120), nullable=False)
    description = Column(String(255), nullable=True)
    widgets_json = Column(Text, default="[]")  # JSON string array of widget configs
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class SupportTicket(Base):
    __tablename__ = "support_tickets"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(200), nullable=False)
    client_name = Column(String(120), nullable=False)
    category = Column(String(80), default="Invoice Clarification")  # Invoice Clarification, Payment Dispute, Contract, General
    priority = Column(String(30), default="Medium")  # Low, Medium, High, Urgent
    status = Column(String(30), default="Open")  # Open, In Progress, Waiting on Client, Resolved
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class ClientLog(Base):
    __tablename__ = "client_logs"
    id = Column(Integer, primary_key=True, index=True)
    client_name = Column(String(120), nullable=False)
    contact_email = Column(String(150), nullable=True)
    activity_type = Column(String(60), default="Reminder")  # Reminder, Phone Call, Meeting, Dispute Log
    details = Column(Text, nullable=False)
    follow_up_date = Column(String(40), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

# Create only new tables; existing tables are not modified
Base.metadata.create_all(bind=engine)

def seed_initial_module_data():
    """Seeds initial starter custom dashboard and sample management records if empty."""
    db = SessionLocal()
    try:
        # 1. Starter custom dashboard
        if db.query(CustomDashboard).count() == 0:
            default_widgets = [
                {"id": "w1", "type": "metric", "title": "Revenue Realization Rate", "metricKey": "realizationRate"},
                {"id": "w2", "type": "customer_breakdown", "title": "Top Clients by Volume"},
                {"id": "w3", "type": "status_chart", "title": "Invoice Status Distribution"},
                {"id": "w4", "type": "aging_summary", "title": "Pending Receivables Watchlist"}
            ]
            d1 = CustomDashboard(
                title="Executive Overview",
                description="High-level financial KPIs, client revenue concentration, and collection velocity.",
                widgets_json=json.dumps(default_widgets)
            )
            d2 = CustomDashboard(
                title="Cash Flow Acceleration",
                description="Focus on pending invoices, overdue accounts, and payment risk.",
                widgets_json=json.dumps([
                    {"id": "w1", "type": "metric", "title": "Pending Receivables", "metricKey": "pendingAmount"},
                    {"id": "w2", "type": "aging_summary", "title": "Actionable Follow-up List"}
                ])
            )
            db.add_all([d1, d2])

        # 2. Starter support tickets
        if db.query(SupportTicket).count() == 0:
            t1 = SupportTicket(
                title="Follow-up on Logo Design Approval",
                client_name="Arun",
                category="Invoice Clarification",
                priority="Medium",
                status="In Progress",
                notes="Sent preview mockup. Waiting on Arun to approve the milestone before marking paid."
            )
            t2 = SupportTicket(
                title="Payment gateway query for International Client",
                client_name="Global Tech Ltd",
                category="Payment Dispute",
                priority="High",
                status="Open",
                notes="Client asked whether wire transfer or PayPal is preferred for international transactions."
            )
            db.add_all([t1, t2])

        # 3. Starter client activity logs
        if db.query(ClientLog).count() == 0:
            l1 = ClientLog(
                client_name="Arun",
                contact_email="arun@example.com",
                activity_type="Reminder",
                details="Sent automated reminder email regarding pending invoice approval.",
                follow_up_date="2026-11-20"
            )
            l2 = ClientLog(
                client_name="Apex Media",
                contact_email="billing@apexmedia.io",
                activity_type="Phone Call",
                details="Discussed contract renewal for quarterly branding retainers.",
                follow_up_date="2026-11-25"
            )
            db.add_all([l1, l2])

        db.commit()
    except Exception as e:
        db.rollback()
        print(f"Error seeding module data: {e}")
    finally:
        db.close()

# Run seed on import
seed_initial_module_data()

