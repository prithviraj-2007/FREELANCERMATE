# FreelancerMate — runnable MVP

A full-stack starter app for freelancer invoice creation, payment tracking, and AI-assisted business support.

## What works now
- React dashboard with earnings, pending amount, invoice count and paid count.
- Create invoices from a natural-language prompt using a basic local parser or optional Gemini extraction.
- Review/edit invoice fields before saving.
- SQLite persistence through FastAPI + SQLAlchemy.
- Approve invoices, list and delete invoices.
- Responsive layout for laptop and mobile.
- PayPal Checkout for approved invoices when server credentials are configured. The backend verifies the completed capture, amount, and currency before marking an invoice paid.
- A Vercel serverless AI assistant using the Vercel AI SDK and Gemini. Local Vite development continues to use the existing FastAPI assistant.

## Important
- Approving an invoice is a local review step; it does not send an invoice by email.
- Without PayPal credentials, "Paid (demo)" manually changes the local status and does not verify a real transaction.
- The starter app does not include user authentication. Add authentication and authorization before exposing customer records or live payment endpoints publicly.

## Requirements
- Python 3.10+
- Node.js 18+

## Run backend
Open terminal 1:
```bash
cd backend
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
# Optional: copy .env.example to .env and configure Gemini/PayPal.
uvicorn main:app --reload --port 8001
```
Backend: http://127.0.0.1:8001  
API docs: http://127.0.0.1:8001/docs

## Run frontend locally
Open terminal 2:
```bash
cd frontend
npm install
npm run dev
```
Open the local URL printed by Vite (usually http://localhost:5173).

## Example prompt
`Create an invoice for Arun for 12000 for logo design`

Review the extracted customer, service and amount in the form, then save it.

## PayPal sandbox checkout
1. In the [PayPal Developer Dashboard](https://developer.paypal.com/dashboard/), create a sandbox REST app and copy its client ID and secret.
2. Copy `backend/.env.example` to `backend/.env`. Set `PAYPAL_MODE=sandbox`, `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET`, and `PAYPAL_CURRENCY`.
3. Invoice amounts are currently stored in INR. The default PayPal currency is INR; confirm that your PayPal account and buyer region support it.
4. Restart FastAPI, create and approve an invoice, then use the PayPal button to complete checkout with a sandbox buyer account.
5. After sandbox testing, set live credentials and `PAYPAL_MODE=live`. Keep the secret on the backend, use HTTPS, and do not enable live payments until you have tested your configuration.

`GET /paypal/config` returns the public client ID and UI settings only. The secret is never returned. Production deployments should additionally configure verified PayPal webhooks for reconciliation and payment events outside an active checkout.

## Vercel AI SDK agent
1. Deploy `frontend/` as the Vercel project root. Vercel's `/api/assistant` function uses `ai` and `@ai-sdk/google`.
2. Add `GEMINI_API_KEY`, `GEMINI_MODEL` (optional), and `BACKEND_API_URL` (the publicly reachable FastAPI base URL) as server-side Vercel environment variables. Set `VITE_API_URL` to that same backend URL for the dashboard and PayPal API. On the backend host, set `BACKEND_CORS_ORIGINS` to your exact Vercel site origin (for example, `https://your-project.vercel.app`).
3. Redeploy after setting environment variables. The assistant sends dashboard totals and recent invoice fields to Gemini to answer business questions.
4. For local Vercel-function testing, link the project and run `npx vercel dev` from `frontend/`; use Vercel's local environment or an untracked `frontend/.env.local` for `GEMINI_API_KEY` and `BACKEND_API_URL`. Plain `npm run dev` uses the existing FastAPI assistant.

Never prefix server secrets with `VITE_`: Vite variables with that prefix are included in browser code. Do not send customer data to an AI provider unless you are comfortable with its data handling.

## Troubleshooting
- If the frontend says it cannot connect, make sure the backend terminal is running.
- If `npm` or `python` is not recognised, install Node.js or Python and reopen VS Code.
- If port 8001 is busy, run FastAPI on another port and update `VITE_API_URL` in `frontend/.env` to match.
- If PayPal is not shown, verify both PayPal credentials are set on the backend and that the invoice has been approved.
- If PayPal rejects an INR order, confirm your account supports INR or align invoice and PayPal currencies before trying again.
- Local data is stored in `backend/freelancemate.db`.
